/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package customerAddress;

import ejb.customerLocal;
import entity.Address;
import entity.Customer;
import java.util.Collection;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.inject.Named;
import javax.enterprise.context.ApplicationScoped;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author Radhika Maniya
 */
@Named(value = "managedBean")
@ApplicationScoped
public class ManagedBean {

    @EJB
    private customerLocal customer;
    
    Customer c = new Customer();
    Address a = new Address();
    
    
            
    Collection<Customer> castomer;
    private int addressId;
    private int customerId;
    private String street;
    private String city;
    private String state;
    private String zip;

    public Customer getC() {
        return c;
    }

    public void setC(Customer c) {
        this.c = c;
    }

    public Address getA() {
        return a;
    }

    public void setA(Address a) {
        this.a = a;
    }

    public Collection<Customer> getCastomer() {
        return castomer;
    }

    public void setCastomer(Collection<Customer> castomer) {
        this.castomer = castomer;
    }

    public int getAddressId() {
        return addressId;
    }

    public void setAddressId(int addressId) {
        this.addressId = addressId;
    }

    public int getCustomerId() {
        return customerId;
    }

    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    public String getStreet() {
        return street;
    }

    public void setStreet(String street) {
        this.street = street;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getZip() {
        return zip;
    }

    public void setZip(String zip) {
        this.zip = zip;
    }

   
    /**
     * Creates a new instance of ManagedBean
     */
    public ManagedBean() {
       
    }
      @PostConstruct
    public void init(){
        castomer = customer.getAllCustomers();
    }
    public Collection<Address> ShowAddresses(){
           return customer.getAddresses(city, state);  
    }
    
    public String addAddress(){
        customer.addAddresOfCustomer(street, city, state, zip, customerId);
        return "index";
    }
    
    public void deleteAddress(){
       customer.removeAddressOfCustomer(addressId, customerId);
    }
    
    public String edit(Address A)
    {
        this.addressId=A.getAddressId();
        this.state=A.getState();
        this.city=A.getCity();
        this.street=A.getStreet();
        this.zip=A.getZip();
        Customer c = A.getCustomerId();
        this.customerId =c.getCustomerID();
        this.a = new Address();
        return "editAddress";
        
    }
    
    public String edit()
    {
        this.customer.updateAddresOfCustomer(addressId, street, city, state, zip, customerId);
        return "index";
    }
    
    public void delete(Address add)
    {
        this.addressId = add.getAddressId();
        Customer c = add.getCustomerId();
        this.customerId = c.getCustomerID();
        this.customer.removeAddressOfCustomer(addressId, customerId);
    }
}
