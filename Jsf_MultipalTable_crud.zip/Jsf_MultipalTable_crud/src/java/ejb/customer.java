/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejb;

import entity.Address;
import entity.Customer;
import java.util.Collection;
import java.util.Date;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author Radhika Maniya
 */
@Stateless
public class customer implements customerLocal {
 @PersistenceContext(unitName = "Jsf_MultipalTable_crudPU")
    EntityManager em;
    @Override
    public Collection<Customer> getAllCustomers() {
       return em.createNamedQuery("Customer.findAll").getResultList();
    }

    @Override
    public void addAddresOfCustomer(String street, String city, String state, String zip, Integer custId) {
Customer c = em.find(Customer.class, custId);
    Collection<Address> addresses = c.getAddressCollection();
    
    Address address = new Address();
    address.setStreet(street);
    address.setCity(city);
    address.setState(state);
    address.setZip(zip);
    address.setCustomerId(c); // Very Important
    
    addresses.add(address);
    c.setAddressCollection(addresses);
    
    em.persist(address);
    em.merge(c);
        }

    @Override
    public void updateAddresOfCustomer(Integer addressId, String street, String city, String state, String zip, Integer custId) {
         Address a=em.find(Address.class,addressId);
         Customer c = em.find(Customer.class, custId);
    
//         a.setAddressId(addressId);
         a.setState(state);
          a.setCity(city);
          a.setStreet(street);
          a.setZip(zip);
         a.setCustomerId(c);
         
       em.merge(a);
    }

    @Override
    public void removeAddressOfCustomer(Integer addressId, Integer custId) {
Customer c = em.find(Customer.class, custId);
    Address address = em.find(Address.class, addressId);
    
    Collection<Address> addresses = c.getAddressCollection();
    
    if(addresses.contains(address))
    {
        addresses.remove(address);
        c.setAddressCollection(addresses);
        em.remove(address);
        em.merge(c);
    }
        }

    @Override
    public Collection<Address> getAddresesOfCustomer(Integer custId) {
Customer c = em.find(Customer.class, custId);
    
   return c.getAddressCollection();
    }

    @Override
    public Collection<Address> getAddressesByCity(String city) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Collection<Address> getAddressesByState(String state) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Collection<Address> getAddressesByZip(String zip) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Collection<Address> getAddresses(String city, String State) {
           return em.createNamedQuery("Address.findAll").getResultList();

    }

    // Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Business Method")
}
