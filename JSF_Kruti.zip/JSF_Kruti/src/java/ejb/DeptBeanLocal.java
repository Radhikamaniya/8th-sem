/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejb;

import entity.Department;
import entity.Employee;
import java.util.Collection;
import javax.ejb.Local;

/**
 *
 * @author Radhika Maniya
 */
@Local
public interface DeptBeanLocal {
        public void AddDept(String deptName);
    public void EditDept(Integer deptId,String deptName);
    public void DeleteDept(int deptId);
    public Collection<Department> getDept();
    public String getDetById(int deptId);
    Collection<Employee> getEmpsByDept(Integer did);
}
