/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejb;

import entity.Department;
import entity.Employee;
import java.util.Collection;
import javax.ejb.Local;

/**
 *
 * @author Radhika Maniya
 */
@Local
public interface EmployeeBeanLocal {
     public void insertEmployee(String empname,int deptid);
    public Employee displayByEmpId(int empid);
    public void updateEmployee(int empid,String empname,int deptid);
    public void deleteEmployee(int empid);
    public Collection<Employee> getEmpByDeptNames(Collection<String> deptNames);
    public Collection<Employee> displayByDeptId(int deptid);
    public Collection<Employee> displayAllEmployee();
    public Collection<Department> getAlldepartments();
}
