/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejb;

import entity.Department;
import entity.Employee;
import java.util.ArrayList;
import java.util.Collection;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author Radhika Maniya
 */
@Stateless
public class EmployeeBean implements EmployeeBeanLocal {
@PersistenceContext(unitName = "JSF_KrutiPU")
    EntityManager em;

    @Override
    public void insertEmployee(String empname, int deptid) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Employee displayByEmpId(int empid) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void updateEmployee(int empid, String empname, int deptid) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void deleteEmployee(int empid) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Collection<Employee> displayByDeptId(int deptid) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Collection<Employee> displayAllEmployee() {
               return em.createNamedQuery("Employee.findAll").getResultList();
    }

    @Override
    public Collection<Employee> getEmpByDeptNames(Collection<String> deptNames) {
       Collection<Department> depts=em.createNamedQuery("Department.findByDeptNames")
                .setParameter("deptNames", deptNames)
                .getResultList();
        
        Collection<Employee> emps=new ArrayList<Employee>();
        
        for(Department d:depts){
            emps.addAll(d.getEmployeeCollection());
        }
        return emps;
    }

    @Override
    public Collection<Department> getAlldepartments() {
               return em.createNamedQuery("Department.findAll").getResultList();

    }
   
}
