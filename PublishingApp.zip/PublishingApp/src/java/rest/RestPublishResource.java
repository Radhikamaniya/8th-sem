
package rest;

import ejb.PublishBeanLocal;
import entity.Address;
import entity.Customer;
import entity.Subscription;
import java.util.Collection;
import javax.ejb.EJB;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Path("publish")
public class RestPublishResource {
    
    @EJB PublishBeanLocal pbl;

    @Context
    private UriInfo context;

    public RestPublishResource() {
    }

   @GET
   @Produces(MediaType.APPLICATION_JSON)
    public Collection<Customer> getAllCustomers() {
       // throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
   
       return pbl.getAllCustomers();
    
    }

    @Path("addcustomer/{fname}/{lname}")
    @POST
    public void addCustomer(@PathParam("fname") String firstName, @PathParam("lname") String lastName) {
    pbl.addCustomer(firstName, lastName);
    }
 
    @Path("remcust/{id}")
    @DELETE
    public void removeCustomer(@PathParam("id") Integer custId) {
      pbl.removeCustomer(custId);
    }

    @Path("getcustbyfname/{fname}")
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Collection<Customer> getCustomerByFirstName(@PathParam("fname") String fname) {
     
     return pbl.getCustomerByFirstName(fname);
    
    }

    @Path("getcustbyid/{id}")
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Customer getCustomerById(@PathParam("id") Integer custId) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    
        return pbl.getCustomerById(custId);
    }

    @Path("addaddress/{street}/{city}/{state}/{zip}/{id}")
    @POST   
    public void addAddresOfCustomer(@PathParam("street") String street, @PathParam("city") String city, @PathParam("state") String state, @PathParam("zip") String zip, @PathParam("id") Integer custId) {
     
    pbl.addAddresOfCustomer(street, city, state, zip, custId);
    }
    @Path("remaddress/{aid}/{cid}")
    @DELETE
    public void removeAddressOfCustomer(@PathParam("aid") Integer addressId,@PathParam("cid") Integer custId) {
    
    pbl.removeAddressOfCustomer(addressId, custId);
    }

    @Path("getaddressofcust/{id}")
    @GET
    @Produces(MediaType.APPLICATION_JSON)  
    public Collection<Address> getAddresesOfCustomer(@PathParam("id") Integer custId) {
    
   return pbl.getAddresesOfCustomer(custId);
    }

    @Path("addsubs/{title}/{type}")
    @POST
    public void addSubscription(@PathParam("title") String title, @PathParam("type") String type) {
      pbl.addSubscription(title, type);
    }

   @Path("remsubs/{id}")
    @DELETE    
    public void removeSubscription(@PathParam("id") Integer subId) {
    pbl.removeSubscription(subId);
    }

    @Path("getsubsofcust/{id}")
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Collection<Subscription> getSubscriptionsOfCustomer(@PathParam("id") Integer custId) {
    
    return pbl.getSubscriptionsOfCustomer(custId);
    }
  
    @Path("getcustsofsub/{id}")
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Collection<Customer> getCustomersOfSubscription(@PathParam("id") Integer subId) {
       
    return pbl.getCustomersOfSubscription(subId);
    }

    @Path("addsubsofcust/{id}")
    @POST    
    @Consumes(MediaType.APPLICATION_JSON)
    public void addSubscriptionsToCustomer(@PathParam("id") Integer custId, Collection<Integer> subIds) {
      
        pbl.addSubscriptionsToCustomer(custId, subIds);
    }
    @Path("remsubsofcust/{id}")
    @POST    
    @Consumes(MediaType.APPLICATION_JSON)
    public void removeSubscriptionsOfCustomer(@PathParam("id") Integer custId, Collection<Integer> subIds) {
      pbl.removeSubscriptionsOfCustomer(custId, subIds);
    }
}
