
package servlets;

import RestRadhikaCLient.restRadhikaClient;
import client.RestPublishClient;
import entity.Address;
import entity.Customer;
import entity.Subscription;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collection;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.Response;

@WebServlet(name = "RestPublishServlet", urlPatterns = {"/RestPublishServlet"})
public class RestPublishServlet extends HttpServlet {
    
    Response res;
    //Response res1;
    RestPublishClient  pbl;
    //restRadhikaClient pbl1;
    Collection<Customer> customers;
    GenericType<Collection<Customer>> gcustomers;
    Collection<Address> addresses;
    GenericType<Collection<Address>> gaddresses;
    Collection<Subscription> subscriptions;
    GenericType<Collection<Subscription>> gsubscriptions;

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet RestPublishServlet</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet RestPublishServlet at " + request.getContextPath() + "</h1>");
            out.println("<body><h3>");
            
            pbl =  new RestPublishClient();
             //pbl1 =  new restRadhikaClient();
             
            gcustomers= new GenericType<Collection<Customer>>(){};
             gaddresses= new GenericType<Collection<Address>>(){};
            gsubscriptions= new GenericType<Collection<Subscription>>(){};
           
            
           // pbl.addCustomer("Vikram", "Sampat");
           
        //   pbl.addAddresOfCustomer("A-213", "Surat","Gujarat", "395001", "29");
        //    pbl.addAddresOfCustomer("S-1", "Vadodara","Gujarat", "381006", "29");
        // pbl.removeAddressOfCustomer("23", "29");
        // pbl.removeAddressOfCustomer("24", "29");
        //pbl1.removeCustomer("2");
          Collection sids = new ArrayList<Integer>();
          sids.add(1);
          sids.add(3);
          sids.add(4);
          
         // pbl.addSubscriptionsToCustomer(sids,"29");
          //pbl.removeSubscriptionsOfCustomer(sids, "29");
          
          
         res = pbl.getAllCustomers(Response.class);
        // res1 = pbl1.getAllCustomers(Response.class);
//         Collection<Customer> customers1 = res1.readEntity(gcustomers);
//            
//            for(Customer c : customers1)
//            {
//             out.println("custId of radhika : "+ c.getCustomerID() + " Name : " + c.getFirstName()+" "+ c.getLastName());
//             
          Collection<Customer> customers = res.readEntity(gcustomers);
            
            for(Customer c : customers)
            {
             out.println("custId : "+ c.getCustomerID() + " Name : " + c.getFirstName()+" "+ c.getLastName());
             
             
             res = pbl.getAddresesOfCustomer(Response.class,c.getCustomerID().toString());
             Collection<Address> addresses = res.readEntity(gaddresses);
             
             for(Address a : addresses)
             {
                  out.println("<br/>AddressId : "+ a.getAddressId() + " Street : "+ a.getStreet()+ " City : " + a.getCity()+"  State : "+ a.getState());
             
             }
             res = pbl.getSubscriptionsOfCustomer(Response.class, c.getCustomerID().toString());
             Collection<Subscription> subscriptions = res.readEntity(gsubscriptions);
          
             for(Subscription s : subscriptions)
             {
                 out.println("<br/>Subs Id : "+ s.getSubscriptionId() + " Title : "+ s.getTitle()+ " Type : "+ s.getType());
             }
             out.println("<hr/>");
            }
            out.println("</h3>");
            out.println("</html>");
        }
    }
}
