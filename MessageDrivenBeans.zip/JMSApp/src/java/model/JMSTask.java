/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.util.Properties;
import javax.jms.Connection;

import javax.jms.ConnectionFactory;
import javax.jms.MessageProducer;
import javax.jms.Queue;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.jms.Topic;
import javax.jms.TopicConnection;
import javax.jms.TopicConnectionFactory;
import javax.jms.TopicPublisher;
import javax.jms.TopicSession;
import javax.naming.Context;
import javax.naming.InitialContext;

/**
 *
 * @author root
 */
public class JMSTask {
    
    Properties p;

    public JMSTask(String host, Integer port) {
        
         p = new Properties();
        p.setProperty(Context.PROVIDER_URL, "mq://"+host+":"+port);
    }
    
    public void sendToQueue(String jndi, String message)
    {
        try {
            
            InitialContext ic = new InitialContext(p);
        
            Queue queue = (Queue) ic.lookup(jndi);
            
            ConnectionFactory cf = (ConnectionFactory) ic.lookup(jndi+"Factory");
            
            Connection con = cf.createConnection();
            
            Session session = con.createSession();
            
            MessageProducer mp = session.createProducer(queue);
            
            TextMessage tm = session.createTextMessage(message);
            
            mp.send(tm);
            
            con.close();
        
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
    
    
    
    
    
    public void sendToTopic(String jndi, String message)
    {
        try {
            
            InitialContext ic = new InitialContext(p);
        
            Topic topic = (Topic) ic.lookup(jndi);
            
            TopicConnectionFactory cf = (TopicConnectionFactory) ic.lookup(jndi+"Factory");
            
            TopicConnection con = cf.createTopicConnection();
            
            TopicSession session = con.createTopicSession(true, 0);
            
            TopicPublisher tp = session.createPublisher(topic);
            
            TextMessage tm = session.createTextMessage(message);
            
            tp.publish(tm);
            
            con.close();
        
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
    
}
